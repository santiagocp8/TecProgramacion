/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadora;

import Util.Lectura;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
/**
 *
 * @author Santiago C
 */
public class Calculadora {
    BufferedReader bin = new BufferedReader(new InputStreamReader(System.in));
    
    public void OperarAritmeticos() throws IOException{
       double num1;
       double num2;
       int opcion;
       do{
         num1= Lectura.leerDoble(bin, "Ingrese el primer numero: ");
         num2= Lectura.leerDoble(bin, "Ingrese el segundo numero: ");
         opcion = Lectura.leerEntero(bin,"""
                                             \tSeleccione el operador deseado:
                                             1. Suma
                                             2. Resta
                                             3. Multiplicacion
                                             4. Division
                                             5. Salir
                                             Ingrese su opcion: """ );
         switch(opcion){
             case 1:
                    System.out.println(num1 + " + " + num2 + " Es: " + (num1 + num2));
                    break;
                case 2:
                    System.out.println(num1 + " - " + num2 + " Es: " + (num1 - num2));
                    break;
                case 3:
                    System.out.println(num1 + " * " + num2 + " Es: " + (num1 * num2));
                    break;
                case 4:
                    if (num2 == 0) {
                        System.out.println("No se puede dividir por cero.");
                        
                    } else {
                         System.out.println(num1 + " / " + num2 + " Es: " + (num1 / num2));
                    } 
                    break;
                case 5:
                    System.out.println("Usted ha salido con exito");
                    break;
                default:
                    System.out.println("Error, ingrese una opcion valida");
         }
               
        }while (opcion != 5);
    }
    
     public void operarRelacionales() throws IOException {
        double num1;
        double num2;
        int opcion;
        do{
            num1 = Lectura.leerDoble(bin, "\nIngrese el primer numero: ");
            num2 = Lectura.leerDoble(bin, "Ingrese el segundo numero: ");
            opcion = Lectura.leerEntero(bin, """
                                          \tSeleccione el operador deseado:
                                          1. Mayor que
                                          2. Menor que
                                          3. Mayor o Igual que
                                          4. Menor o igual que
                                          5. Igual a
                                          6. Diferente de
                                          7. Salir
                                          Ingrese su opcion: """);
        
            switch (opcion) {
                case 1:
                    System.out.println(num1 + " > " + num2 + " Es: " + (num1 > num2));
                    break;
                case 2:
                    System.out.println(num1 + " < " + num2 + " Es: " + (num1 < num2));
                    break;
                case 3:
                    System.out.println(num1 + " >= " + num2 + " Es: " + (num1 >= num2));
                    break;
                case 4:
                    System.out.println(num1 + " <= " + num2 + " Es: " + (num1 <= num2));
                    break;
                case 5:
                    System.out.println(num1 + " == " + num2 + " Es: " + (num1 == num2));
                    break;
                case 6:
                    System.out.println(num1 + " != " + num2 + " Es: " + (num1 != num2));
                    break;
                case 7:
                    System.out.println("Usted ha salido con exito");
                    break;
                default:
                    System.out.println("Error, ingrese una opcion valida");
            }
        }while (opcion !=7);
    }
     
     public void operarBits()throws IOException{
         int num1;
         int num2;
         int desplazamiento;
         int opcion;
         do{
            
            opcion = Lectura.leerEntero(bin, """
                                          \tSeleccione el operador deseado:
                                          1. AND bit a bit (&)
                                          2. OR bit a bit (|)
                                          3. XOR bit a bit (^)"
                                          4. NOT bit a bit (~)
                                          5. Desplazamiento a la izquierda 
                                          6. Desplazamiento a la derecha
                                          7. Salir
                                          Ingrese su opcion: """);
            switch (opcion){
                   case 1:
                       num1 = Lectura.leerEntero(bin, "\nIngrese el primer numero: ");
                       num2 = Lectura.leerEntero(bin, "Ingrese el segundo numero: ");
                       System.out.println("se compara bit a bit y solo pone a 1 los bits que son 1 en ambos operandos.");
                       System.out.println("El resultado en binario es: "+ Integer.toBinaryString(num1 & num2));
                       System.out.println("El resultado en decimal es: "+ (num1 & num2));
                       break;
                   case 2:
                       num1 = Lectura.leerEntero(bin, "\nIngrese el primer numero: ");
                       num2 = Lectura.leerEntero(bin, "Ingrese el segundo numero: ");
                       System.out.println("se compara bit a bit y solo pone a 1 los bits que son 1 en al menos uno de los operandos.");
                       System.out.println("El resultado en binario es: "+ Integer.toBinaryString(num1 | num2));
                       System.out.println("El resultado en decimal es: "+ (num1 | num2));
                       break;
                   case 3:
                       num1 = Lectura.leerEntero(bin, "\nIngrese el primer numero: ");
                       num2 = Lectura.leerEntero(bin, "Ingrese el segundo numero: ");
                       System.out.println("se compara bit a bit y pone a 1 los bits que son diferentes entre los operandos.");
                       System.out.println("El resultado en binario es: "+ Integer.toBinaryString(num1 ^ num2));
                       System.out.println("El resultado en decimal es: "+ (num1 ^ num2));
                       break;
                   case 4:
                       num1 = Lectura.leerEntero(bin, "\nIngrese el primer numero: ");
                       System.out.println(" invierte todos los bits de un número (cambia los 0 a 1 y los 1 a 0).");
                       System.out.println("El resultado en binario es : "+ Integer.toBinaryString(~num1));
                       System.out.println("El resultado en decimal es: "+ (~num1));
                       break;
                   case 5:
                       num1 = Lectura.leerEntero(bin, "\nIngrese el primer numero: ");
                       desplazamiento=Lectura.leerEntero(bin,"Ingrese el numero de posiciones para el desplazamiento: ");
                       System.out.println("Desplaza los bits del numero hacia la izquierda");
                       System.out.println("El resultado en binario es : "+ Integer.toBinaryString(num1 << desplazamiento));
                       System.out.println("El resultado en decimal es: "+ (num1 << desplazamiento));
                       break;
                   case 6:
                       num1 = Lectura.leerEntero(bin, "\nIngrese el primer numero: ");
                       desplazamiento=Lectura.leerEntero(bin,"Ingrese el numero de posiciones para el desplazamiento: ");
                       System.out.println("Desplaza los bits del numero hacia la derecha");
                       System.out.println("El resultado en binario: "+ Integer.toBinaryString(num1 >> desplazamiento));
                       System.out.println("El resultado en decimal es: "+ (num1 >> desplazamiento));
                       break;
                   case 7:
                    System.out.println("Usted ha salido con exito");
                    break;
                   default:
                       System.out.println("Error, ingrese una opcion valida");
                       
            }
         }while(opcion !=7);
     
     }
     
     public void operarBooleanos() throws IOException{
         boolean exp1;
         boolean exp2;
         int opcion;
         do{
             opcion = Lectura.leerEntero(bin, """
                                          \tSeleccione el operador deseado:
                                          1. AND (&)
                                          2. OR (|)
                                          3. XOR (^)"
                                          4. NOT (!)
                                          5. Salir
                                          Ingrese su opcion: """);
             switch (opcion){
                 case 1:
                     exp1 = Lectura.leerBooleano(bin,"Ingrese true o false: ");
                     exp2 = Lectura.leerBooleano(bin,"Ingrese true o false: ");
                     System.out.println(exp1+" & "+exp2+" es: "+ (exp1 && exp2));
                 case 2:
                     exp1 = Lectura.leerBooleano(bin,"Ingrese true o false: ");
                     exp2 = Lectura.leerBooleano(bin,"Ingrese true o false: ");
                     System.out.println(exp1+" & "+exp2+" es: "+ (exp1 || exp2));
                 case 3:
                     exp1 = Lectura.leerBooleano(bin,"Ingrese true o false: ");
                     exp2 = Lectura.leerBooleano(bin,"Ingrese true o false: ");
                     System.out.println(exp1+" & "+exp2+" es: "+ (exp1 ^ exp2));
                 case 4:
                     exp1 = Lectura.leerBooleano(bin,"Ingrese true o false: ");
                     System.out.println("!"+exp1+" es: "+ (!exp1));
                 case 5:
                    System.out.println("Usted ha salido con exito");
                 default:
                       System.out.println("Error, ingrese una opcion valida");
                       break;
             }
         }while (opcion !=5);
     }
     
     public void operarIncrementales() throws IOException{
        double num;
        int opcion;
        do{
            num = Lectura.leerDoble(bin, "\nIngrese el numero a operar: ");
            opcion = Lectura.leerEntero(bin, """
                                             \tSeleccione el operador deseado:
                                             1. Incrementar en 1
                                             2. Disminuir en 1
                                             3. Incremento
                                             4. Decremento
                                             5. Multiplicacion
                                             6. Division
                                             7. Modulo o Residuo
                                             8. Salir
                                             Ingrese su opcion: """);
        
            switch (opcion) {
                case 1:
                    System.out.println(num + "++ es: " + ++num);
                    break;
                case 2:
                    System.out.println(num + "-- es: " + --num);
                    break;
                case 3:
                    double incremento;
                    incremento = Lectura.leerDoble(bin, "Ingrese el incremento: ");
                    System.out.println(num + "+= " + incremento + " Es: " + (num+incremento));
                    break;
                case 4:
                    double decremento;
                    decremento = Lectura.leerDoble(bin, "Ingrese el decremento: ");
                    System.out.println(num + "-= " + decremento + " Es: " + (num-decremento));
                    break;
                case 5:
                    double multiplicacion;
                    multiplicacion = Lectura.leerDoble(bin, "Ingrese la cantidad por la que desea multiplicar al numero: ");
                    System.out.println(num + "*= " + multiplicacion + " Es: " + (num*multiplicacion));
                    break;
                case 6:
                    double division;
                    division = Lectura.leerDoble(bin, "Ingrese la cantidad por la que desea dividir al numero: ");
                    System.out.println(num + "/= " + division + " Es: " + (num/division) + "Esta operacion unicamente arroja un valor entero");
                    break;
                case 7:
                    double divisor;
                    divisor = Lectura.leerDoble(bin, "Ingrese la cantidad por la que desea dividir al numero para obtener el residuo: ");
                    System.out.println(num + "%= " + divisor + " Es: " + (num%divisor));
                    break;
                case 8:
                    System.out.println("Usted a salido con exito");
                    break;
                default:
                    System.out.println("Error, ingrese una opcion valida");
            }
        }while (opcion !=8);
    }
    
    public void operarCadenas()throws IOException{
        String cadena1;
        String cadena2;
        int opcion;
        do{
            cadena1 = Lectura.leerString(bin, "\nIngrese la primera cadena: ");
            cadena2 = Lectura.leerString(bin, "Ingrese la segunda cadena: ");
            opcion = Lectura.leerEntero(bin, """
                                             \tSeleccione el operador deseado:
                                             1. Concatenar cadenas 
                                             2. Comparar cadenas
                                             3. Salir
                                             Ingrese su opcion: """);

            switch (opcion) {
                case 1:
                    System.out.println(cadena1 + " " + cadena2);
                    break;
                case 2:
                    if (cadena1.equals(cadena2)){
                        System.out.println("La primera cadena: " + cadena1 + " y la segunda cadena " + cadena2 + " Son iguales");
                    }else{
                        System.out.println("La primera cadena: " + cadena1 + " y la segunda cadena " + cadena2 + "  NO son iguales");
                    }
                    break;
                case 3:
                    System.out.println("Usted ha salido con exito");
                    break;
                default:
                    System.out.println("Error, ingrese una opcion valida");
            }
        }while (opcion !=3);
    }
    

    
}
