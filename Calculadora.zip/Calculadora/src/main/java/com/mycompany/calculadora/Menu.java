/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calculadora;

import  Util.Lectura;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Santiago C
 */
public class Menu {
     public  void opciones() throws IOException {
         Calculadora calculadora = new Calculadora();
        BufferedReader bln = new BufferedReader(new InputStreamReader(System.in));
         System.out.println("CALCULADORA:");
         System.out.println("1. Operadores aritmeticos (+, -, *, /)");
         System.out.println("2. Operadores relacionales (>, <, >=, <=, =, !=) ");
         System.out.println("3. Operadores de bit ");
         System.out.println("4. Operadores booleanos ");
         System.out.println("5. Operadores de incremento  ");
         System.out.println("6. Operadores de cadenas de texto ");
         int  opcion = Lectura.leerEntero(bln,"Ingrese el numero del operador que quiere usar: ");
         switch (opcion){
             case 1: 
                calculadora.OperarAritmeticos();
                break;
             case 2:
                 calculadora.operarRelacionales();
                 break;
             case 3:
                 calculadora.operarBits();
                 break;
             case 4:
                 calculadora.operarBooleanos();
                 break;
             case 5:
                 calculadora.operarIncrementales();
                 break;
             case 6:
                 calculadora.operarCadenas();
                 break;
             case 7:
                 System.out.println("Usted ha salido con exito");
                 break;
             default:
                 System.out.println("Error, ingrese una opcion valida");
         
         }
         
         
       
        
        
        
      
      
      
}
    
}
