/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ManejoArchivos;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mycompany.administracionhojasverdes.Persona;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author margot.lopez
 */
public class LecturaJson {
    public static void main(String[] args) throws IOException {   
        Gson gson = new Gson();     
        String fileJson = "C:\\Users\\Usuario\\Documents\\NetBeansProjects\\ArchivosJSON\\src\\Datos\\datosJson.json";        
        String infomia = "";
        
        try (BufferedReader br = new BufferedReader(new FileReader(fileJson))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                infomia += linea;  
            }
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        //  propiedades del archivo Json
        // estracciòn de la informaciòn que String  bajo  json
        Properties properties = gson.fromJson(infomia, Properties.class);
        System.out.println(properties.get("nombre"));
        System.out.println(properties.get("apellidos"));
        System.out.println(properties.get("edad"));
                         
        //  gestión del Json al bean
        Persona persona = gson.fromJson(infomia, Persona.class);
        System.out.println(persona);        
        
   }
}

