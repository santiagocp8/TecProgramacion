/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManejoArchivos;

import com.mycompany.administracionhojasverdes.Persona;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Santiago C
 */
public class InicioDeSesion {
    List<Persona> listaUsuarios = new ArrayList<>();
    
     public static String  verificarUsuario(String nombre, String Id) {
        List<Persona> listaUsuariosRecuperada = leerArchivo();
         
        if (listaUsuariosRecuperada == null) {
            System.out.println("No se pudieron recuperar los usuarios registrados.");
            return null;
        }

        
        for (Persona usuario : listaUsuariosRecuperada) {
            if (usuario.getNombre().equals(nombre) && usuario.getId().equals(Id)) {
                return usuario.getRol() ;  // Credenciales correctas
            }
        }
        return null;  // Si no encuentra coincidencias
     }
     
    public void guardarArchivo(){
        try (PrintWriter pw = new PrintWriter(new FileWriter("Usuarios.csv", true))) {
            for (Persona usuario : listaUsuarios) {
                pw.println(usuario.getNombre() + "," + usuario.getId());
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    
    }
    
    public static  List<Persona> leerArchivo() {
        List<Persona> listaRecuperada = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Usuarios.csv"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                String Id = datos[0];
                String nombre = datos[1];
                String rol = datos[3];
                listaRecuperada.add(new Persona(nombre, Id, rol));
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return listaRecuperada;
    }
}
