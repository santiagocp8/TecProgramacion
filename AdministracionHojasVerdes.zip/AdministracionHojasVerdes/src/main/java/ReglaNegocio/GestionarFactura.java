/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReglaNegocio;

import com.mycompany.administracionhojasverdes.Propiedad;
import com.mycompany.administracionhojasverdes.Factura;
import com.mycompany.administracionhojasverdes.ZonasComunes;
import java.io.*;
import java.util.*;

/**
 *
 * @author Santiago C
 */
public class GestionarFactura {
    List<Factura> listaFacturas = new ArrayList<>();
    Propiedad casa = new Propiedad();
    ZonasComunes zona = new ZonasComunes();
    Factura cuentas = new Factura();
    
    double cuentasVencidas = cuentas.getCuentasVencidas();
    double metrosCuadrados = casa.getMetrosCuadrados();
    double mantenimiento = zona.getCostoMantenimiento();
    double valorTotal;
    double valorAdministracion;
    double valorMetroCuadrado = 23.50;
    
    
    
    
        public void guardarFactura(){
        try (PrintWriter pw = new PrintWriter(new FileWriter("Facturas.csv", true))) {
            for (Factura factura : listaFacturas) {
                pw.println(factura.getId()+","+ factura.getFecha()+","+factura.getPropiedad()+","+
                        factura.getMesFactura()+","+factura.getCuentasVencidas()+","+factura.getDescuento()+","+factura.getFechaMaximaPago());
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    
    }         
 
        public static List<Factura> LeerFactura() {
        List<Factura> listaFacturas = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Facturas.csv"))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length >= 7) {
                    String Id = datos[0];
                    String fecha = datos[1];
                    Propiedad propiedad = new Propiedad(datos[2]);
                    String mesFactura = datos[3];
                    int cuentasVencidas = Integer.parseInt(datos[4]);
                    float descuento = Float.parseFloat(datos[5]);
                    String fechaMaximaPago = datos[6];
                    Factura factura = new Factura(Id, fecha, propiedad, mesFactura, cuentasVencidas, descuento, fechaMaximaPago);
                    listaFacturas.add(factura);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
        return listaFacturas;
    }
    
    
    public void AgregarFactura(Factura factura){
        
        listaFacturas.add(factura); 
        guardarFactura();
    }
    
    public void MostrarFactura( Factura factura){
        StringBuilder sb = new StringBuilder();
        sb.append("ID: ").append(factura.getId()).append("/n");
        sb.append("Fecha de emisión de la factura: ").append(factura.getFecha()).append("/n");
        sb.append("ID de la propiedad: ").append(factura.getPropiedad().getId()).append("/n");
        sb.append("Mes que se factura: ").append(factura.getMesFactura()).append("/n");
        sb.append("Numero de cuentas vencidas: ").append(factura.getCuentasVencidas()).append("/n");
        sb.append("Descuento de: ").append(factura.getDescuento()).append("/n");
        sb.append("Fecha maxima de pago:").append(factura.getFechaMaximaPago()).append("/n");
        sb.append("Valor total a pagar:").append(factura.getValorTotal()).append("/n");
    }
        
    
    
    public  String buscarFacturaPorPropiedad(String Id) {
        for (Factura factura : listaFacturas) {
            if (factura.getPropiedad().getId().equals(Id)) {
                MostrarFactura(factura);
            }
        }
        return null;
    }
    
    public void TotalFactura(){
        valorAdministracion =  ((valorMetroCuadrado*metrosCuadrados)+ mantenimiento);
        double valorConIva= (valorAdministracion*0.19)+ valorAdministracion ;
        valorTotal= valorConIva+(cuentasVencidas*valorAdministracion);
        Factura fac = new Factura();
        fac.setValorTotal((float) valorTotal);
    }
}

