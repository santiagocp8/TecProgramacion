/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReglaNegocio;
import com.mycompany.administracionhojasverdes.Propietarios;
import java.io.*;
import java.util.*;
/**
 *
 * @author Santiago C
 */
public class GestionarPropietario {

    
    public void agregarPropietario(Propietarios propietario) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("ListaPropietarios.csv", true))) {
            writer.write(propietario.getDireccion() + "," +
                         propietario.getTelefono() + "," +
                         propietario.getOficio() + "," +
                         propietario.getProfesion() + "," +
                         propietario.getId() + "," +  
                         propietario.getNombre() + "," + 
                         propietario.getApellidos());
            writer.newLine();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    // Leer todos los propietarios del archivo CSV
    public List<Propietarios> leerPropietarios() {
        List<Propietarios> propietarios = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("ListaPropietarios.csv"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] datos = line.split(",");
                Propietarios propietario = new Propietarios(datos[0], datos[1], datos[2], datos[3], 
                                                          datos[4], datos[5], datos[6]);
                propietarios.add(propietario);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return propietarios;
    }

    
    public void actualizarPropietario(Propietarios propietarioActualizado) {
        List<Propietarios> propietarios = leerPropietarios();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("ListaPropietarios.csv"))) {
            for (Propietarios propietario : propietarios) {
                if (propietario.getId().equals(propietarioActualizado.getId())) {
                    writer.write(propietarioActualizado.getDireccion() + "," +
                                 propietarioActualizado.getTelefono() + "," +
                                 propietarioActualizado.getOficio() + "," +
                                 propietarioActualizado.getProfesion() + "," +
                                 propietarioActualizado.getId() + "," +
                                 propietarioActualizado.getNombre() + "," + 
                                 propietarioActualizado.getApellidos());
                } else {
                    writer.write(propietario.getDireccion() + "," +
                                 propietario.getTelefono() + "," +
                                 propietario.getOficio() + "," +
                                 propietario.getProfesion() + "," +
                                 propietario.getId() + "," +
                                 propietario.getNombre() + "," + 
                                 propietario.getApellidos());
                }
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    
    public void eliminarPropietario(String id) {
        List<Propietarios> propietarios = leerPropietarios();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("ListaPropietarios.csv"))) {
            for (Propietarios propietario : propietarios) {
                if (!propietario.getId().equals(id)) {
                    writer.write(propietario.getDireccion() + "," +
                                 propietario.getTelefono() + "," +
                                 propietario.getOficio() + "," +
                                 propietario.getProfesion() + "," +
                                 propietario.getId() + "," +
                                 propietario.getNombre() + "," + 
                                 propietario.getApellidos());
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}

    

