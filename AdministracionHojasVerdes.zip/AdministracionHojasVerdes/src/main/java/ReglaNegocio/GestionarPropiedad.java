/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReglaNegocio;

import com.mycompany.administracionhojasverdes.Propiedad;
import com.mycompany.administracionhojasverdes.Propietarios;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Santiago C
 */
public class GestionarPropiedad {
    
    public void agregarPropiedad(Propiedad propiedad) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("ListaPropiedades.csv", true))) {
            writer.write(propiedad.getSaldoActual() + "," +  propiedad.getId() + "," +  propiedad.getMetrosCuadrados());
            writer.newLine();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    
    public List<Propiedad> leerPropiedades() {
        List<Propiedad> propiedades = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("ListaPropiedades.csv"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] datos = line.split(",");
                Propiedad propiedad = new Propiedad(datos[0], datos[1], Float.parseFloat(datos[2]), Float.parseFloat(datos[3]));
                propiedades.add(propiedad);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return propiedades;
    }

    
    public void actualizarPropiedad(Propiedad propiedadActualizada) {
        List<Propiedad> propiedades = leerPropiedades();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("ListaPropiedades.csv"))) {
            for (Propiedad propiedad : propiedades) {
                if (propiedad.getId().equals(propiedadActualizada.getId())) {
                    writer.write(propiedadActualizada.getSaldoActual() + "," + propiedadActualizada.getId() + "," +  propiedadActualizada.getMetrosCuadrados());
                } else {
                    writer.write(propiedad.getSaldoActual() + "," + propiedad.getId() + "," +   propiedad.getMetrosCuadrados());
                }
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    // Eliminar una propiedad por su ID
    public void eliminarPropiedad(String id) {
        List<Propiedad> propiedades = leerPropiedades();
        boolean propiedadEncontrada = false;

        for (Propiedad propiedad : propiedades) {
            if (propiedad.getId().equals(id)) {
                propiedadEncontrada = true;
                break;
            }
        }

        if (!propiedadEncontrada) {
            System.out.println("La propiedad con ID " + id + " no existe.");
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("ListaPropiedades.csv"))) {
            for (Propiedad propiedad : propiedades) {
                if (!propiedad.getId().equals(id)) {
                    writer.write(propiedad.getSaldoActual() + "," + propiedad.getId() + "," + propiedad.getMetrosCuadrados());
                    writer.newLine();
                }
            }
            System.out.println("La propiedad con ID " + id + " ha sido eliminada.");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}

    

