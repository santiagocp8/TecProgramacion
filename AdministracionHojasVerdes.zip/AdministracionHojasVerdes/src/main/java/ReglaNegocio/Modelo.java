/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReglaNegocio;

/**
 *
 * @author Santiago C
 */
public class Modelo {
    public static final GestionarEmpleado empleado = new GestionarEmpleado();
    public static final GestionarPropiedad propiedad = new GestionarPropiedad();
    public static final GestionarPropietario propietario = new GestionarPropietario();
    public static final GestionarFactura factura = new GestionarFactura();
}
