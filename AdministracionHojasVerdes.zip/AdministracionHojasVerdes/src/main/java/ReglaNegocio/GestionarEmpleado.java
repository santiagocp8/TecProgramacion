/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReglaNegocio;

import com.mycompany.administracionhojasverdes.Empleados;
import com.mycompany.administracionhojasverdes.Persona;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Santiago C
 */
public class GestionarEmpleado  {
    
    List<Empleados> empleados = new ArrayList<>();

    public void Crear(Empleados empleado) {
        empleados.add(empleado);
        guardarArchivo();
    }

    public void Actualizar(Empleados empleadoActualizado) {
       List<Empleados> empleados = leerEmpleados(); // Leer todos los empleados del archivo
       try (BufferedWriter writer = new BufferedWriter(new FileWriter("ListaEmpleados.csv"))) {
        for (Empleados emp : empleados) {
            if (emp.getId().equals(empleadoActualizado.getId())) {
                // Si encontramos el empleado con el ID, escribimos los nuevos datos
                writer.write(empleadoActualizado.getId() + "," + empleadoActualizado.getNombre() + "," +
                             empleadoActualizado.getApellidos() + "," + empleadoActualizado.getCargo() + "," +
                             empleadoActualizado.getFechaInicio());
            } else {
                // Si no es el empleado que buscamos, escribimos los datos sin cambios
                writer.write(emp.getId() + "," + emp.getNombre() + "," + emp.getApellidos() + "," +
                             emp.getCargo() + "," + emp.getFechaInicio());
            }
            writer.newLine(); // Para que cada empleado quede en una línea separada
        }
      } catch (IOException e) {
          System.out.println(e.getMessage());
       }    
    }

    public void eliminarEmpleado(String id) {
    List<Empleados> empleados = leerEmpleados(); // Leer todos los empleados desde el archivo
    boolean empleadoEncontrado = false;

    // Verificamos si existe un empleado con el ID dado
    for (Empleados emp : empleados) {
        if (emp.getId().equals(id)) {
            empleadoEncontrado = true;
            break;
        }
    }

    if (!empleadoEncontrado) {
        System.out.println("El empleado con ID " + id + " no existe.");
        return; // Salimos del método si no se encuentra el empleado
    }

    // Reescribimos el archivo si el empleado fue encontrado
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("ListaEmpleados.csv"))) {
        for (Empleados emp : empleados) {
            if (!emp.getId().equals(id)) {
                // Solo escribimos los empleados cuyo ID no coincide con el que queremos eliminar
                writer.write(emp.getId() + "," + emp.getNombre() + "," + emp.getApellidos() + "," 
                            + emp.getCargo() + "," + emp.getFechaInicio());
                writer.newLine();
            }
        }
        System.out.println("El empleado con ID " + id + " ha sido eliminado.");
    } catch (IOException e) {
        System.out.println(e.getMessage());
    }
}

    
    public void guardarArchivo(){
        try (PrintWriter pw = new PrintWriter(new FileWriter("ListaEmpleados.csv", true))) {
            for (Empleados empleado : empleados) {
                pw.println(empleado.getId() + "," + empleado.getNombre() + "," + empleado.getApellidos() + "," 
                        + empleado.getCargo() + "," + empleado.getFechaInicio());
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    
    }
    
     public static  List<Empleados> leerEmpleados() {
        List<Empleados> empleados = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("ListaEmpleado.csv"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] datos = line.split(",");
                Empleados empleado = new Empleados(datos[3], datos[4], datos[0], datos[1], datos[2]);
                empleados.add(empleado);
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        
        }return empleados;
    }
}
