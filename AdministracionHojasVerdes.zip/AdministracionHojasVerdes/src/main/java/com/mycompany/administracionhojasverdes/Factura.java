/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.administracionhojasverdes;

/**
 *
 * @author Santiago C
 */
public class Factura {
    private String Id;
    private String fecha;
    private Propiedad propiedad;
    private String mesFactura;
    private int cuentasVencidas;
    private float descuento;
    private String fechaMaximaPago;
    private float valorTotal;

    public Factura(String Id, String fecha, Propiedad propiedad, String mesFactura, int cuentasVencidas, float descuento, String fechaMaximaPago, float valorTotal) {
        this.Id = Id;
        this.fecha = fecha;
        this.propiedad = propiedad;
        this.mesFactura = mesFactura;
        this.cuentasVencidas = cuentasVencidas;
        this.descuento = descuento;
        this.fechaMaximaPago = fechaMaximaPago;
        this.valorTotal = valorTotal;
    }
    

    public Factura() {
    }

    
    

    public Factura(String Id, String fecha, Propiedad propiedad, String mesFactura, int cuentasVencidas, float descuento, String fechaMaximaPago) {
        this.Id = Id;
        this.fecha = fecha;
        this.propiedad = propiedad;
        this.mesFactura = mesFactura;
        this.cuentasVencidas = cuentasVencidas;
        this.descuento = descuento;
        this.fechaMaximaPago = fechaMaximaPago;
    }

    public String getFechaMaximaPago() {
        return fechaMaximaPago;
    }

    public void setFechaMaximaPago(String fechaMaximaPago) {
        this.fechaMaximaPago = fechaMaximaPago;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }

    public String getMesFactura() {
        return mesFactura;
    }

    public void setMesFactura(String mesFactura) {
        this.mesFactura = mesFactura;
    }

    public int getCuentasVencidas() {
        return cuentasVencidas;
    }

    public void setCuentasVencidas(int cuentasVencidas) {
        this.cuentasVencidas = cuentasVencidas;
    }

    public float getDescuento() {
        return descuento;
    }

    public void setDescuento(float descuento) {
        this.descuento = descuento;
    }

    @Override
    public String toString() {
        return "Factura{" + "Id=" + Id + ", fecha=" + fecha + ", propiedad=" + propiedad + ", mesFactura=" + mesFactura + ", cuentasVencidas=" + cuentasVencidas + ", descuento=" + descuento + ", fechaMaximaPago=" + fechaMaximaPago + '}';
    }

    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    

    

    
}
