/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.administracionhojasverdes;

/**
 *
 * @author Santiago C
 */
public class Propietarios extends Persona{
    private String Direccion;
    private String telefono;
    private String oficio;
    private String profesion;

    public Propietarios(String nombre) {
        super(nombre);
    }
    
    

    public Propietarios(String Direccion, String telefono, String oficio, String profesion) {
        this.Direccion = Direccion;
        this.telefono = telefono;
        this.oficio = oficio;
        this.profesion = profesion;
    }

    public Propietarios(String Direccion, String telefono, String oficio, String profesion, String Id, String nombre, String apellidos) {
        super(Id, nombre, apellidos);
        this.Direccion = Direccion;
        this.telefono = telefono;
        this.oficio = oficio;
        this.profesion = profesion;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getOficio() {
        return oficio;
    }

    public void setOficio(String oficio) {
        this.oficio = oficio;
    }

    @Override
    public String toString() {
        return "Propietario{" + "Direccion=" + Direccion + ", telefono=" + telefono + ", oficio=" + oficio + ", profesion=" + profesion + '}';
    }
    
}
