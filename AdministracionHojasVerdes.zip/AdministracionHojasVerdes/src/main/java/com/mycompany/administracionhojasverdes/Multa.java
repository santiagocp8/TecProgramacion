/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.administracionhojasverdes;

/**
 *
 * @author Santiago C
 */
public class Multa {
    private String id;
    private String fechaMulta;
    private String fechaEventoMulta;
    private ZonasComunes espacio;
    private Propiedad casa;
    private Propietarios dueño;
    private String personaOriginaEvento;
    private String evento;
    private String DescripcionEvento;
    private float valorMulta;
    private String fechaMaximaPago;
    private String observacion;

    public Multa(String id, String fechaMulta, String fechaEventoMulta, ZonasComunes espacio, Propiedad casa, Propietarios dueño, String personaOriginaEvento, String evento, String DescripcionEvento, float valorMulta, String fechaMaximaPago, String observacion) {
        this.id = id;
        this.fechaMulta = fechaMulta;
        this.fechaEventoMulta = fechaEventoMulta;
        this.espacio = espacio;
        this.casa = casa;
        this.dueño = dueño;
        this.personaOriginaEvento = personaOriginaEvento;
        this.evento = evento;
        this.DescripcionEvento = DescripcionEvento;
        this.valorMulta = valorMulta;
        this.fechaMaximaPago = fechaMaximaPago;
        this.observacion = observacion;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFechaMulta() {
        return fechaMulta;
    }

    public void setFechaMulta(String fechaMulta) {
        this.fechaMulta = fechaMulta;
    }

    public String getFechaEventoMulta() {
        return fechaEventoMulta;
    }

    public void setFechaEventoMulta(String fechaEventoMulta) {
        this.fechaEventoMulta = fechaEventoMulta;
    }

    public ZonasComunes getEspacio() {
        return espacio;
    }

    public void setEspacio(ZonasComunes espacio) {
        this.espacio = espacio;
    }

    public Propiedad getCasa() {
        return casa;
    }

    public void setCasa(Propiedad casa) {
        this.casa = casa;
    }

    public Propietarios getDueño() {
        return dueño;
    }

    public void setDueño(Propietarios dueño) {
        this.dueño = dueño;
    }

    public String getPersonaOriginaEvento() {
        return personaOriginaEvento;
    }

    public void setPersonaOriginaEvento(String personaOriginaEvento) {
        this.personaOriginaEvento = personaOriginaEvento;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    public String getDescripcionEvento() {
        return DescripcionEvento;
    }

    public void setDescripcionEvento(String DescripcionEvento) {
        this.DescripcionEvento = DescripcionEvento;
    }

    public float getValorMulta() {
        return valorMulta;
    }

    public void setValorMulta(float valorMulta) {
        this.valorMulta = valorMulta;
    }

    public String getFechaMaximaPago() {
        return fechaMaximaPago;
    }

    public void setFechaMaximaPago(String fechaMaximaPago) {
        this.fechaMaximaPago = fechaMaximaPago;
    }

    @Override
    public String toString() {
        return "Multa{" + "id=" + id + ", fechaMulta=" + fechaMulta + ", fechaEventoMulta=" + fechaEventoMulta + ", espacio=" + espacio + ", casa=" + casa + ", due\u00f1o=" + dueño + ", personaOriginaEvento=" + personaOriginaEvento + ", evento=" + evento + ", DescripcionEvento=" + DescripcionEvento + ", valorMulta=" + valorMulta + ", fechaMaximaPago=" + fechaMaximaPago + ", observacion=" + observacion + '}';
    }
}
