/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.administracionhojasverdes;

/**
 *
 * @author Santiago C
 */
public class Propiedad {
    private String dueño;
    private String id;
    private float saldoActual;
    private float metrosCuadrados;

    public Propiedad(String dueño, String id, float saldoActual, float metrosCuadrados) {
        this.dueño = dueño;
        this.id = id;
        this.saldoActual = saldoActual;
        this.metrosCuadrados = metrosCuadrados;
    }

    public Propiedad() {
        
    }

    public Propiedad(String id) {
        this.id = id;
    }
    

    public float getMetrosCuadrados() {
        return metrosCuadrados;
    }

    public void setMetrosCuadrados(float metrosCuadrados) {
        this.metrosCuadrados = metrosCuadrados;
    }

    public String getDueño() {
        return dueño;
    }

    public void setDueño(String dueño) {
        this.dueño = dueño;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public float getSaldoActual() {
        return saldoActual;
    }

    public void setSaldoActual(float saldoActual) {
        this.saldoActual = saldoActual;
    }

    @Override
    public String toString() {
        return "Casa{" + "due\u00f1o=" + dueño + ", id=" + id + ", saldoActual=" + saldoActual + ", metrosCuadrados=" + metrosCuadrados + '}';
    }
    
}
