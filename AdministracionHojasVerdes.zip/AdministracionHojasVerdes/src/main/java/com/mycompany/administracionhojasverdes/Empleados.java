/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.administracionhojasverdes;

/**
 *
 * @author Santiago C
 */
public class Empleados extends Persona{
    private String cargo;
    private String fechaInicio;

    public Empleados(String cargo, String fechaInicio) {
        this.cargo = cargo;
        this.fechaInicio = fechaInicio;
    }

    public Empleados(String cargo, String fechaInicio, String Id, String nombre, String apellidos) {
        super(Id, nombre, apellidos);
        this.cargo = cargo;
        this.fechaInicio = fechaInicio;
    }

    public Empleados() {
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    @Override
    public String toString() {
        return "Empleado{" + "cargo=" + cargo + ", fechaInicio=" + fechaInicio + '}';
    }

    
}
