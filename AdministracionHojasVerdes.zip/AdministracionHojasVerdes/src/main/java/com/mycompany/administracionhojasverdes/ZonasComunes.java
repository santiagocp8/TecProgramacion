/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.administracionhojasverdes;

/**
 *
 * @author Santiago C
 */
public class ZonasComunes {
    private String descripcion;
    private String horaInicio;
    private String horaCierre;
    private double costoMantenimiento = 56.23;

    public ZonasComunes(String descripcion, String horaInicio, String horaCierre, double costoMantenimiento) {
        this.descripcion = descripcion;
        this.horaInicio = horaInicio;
        this.horaCierre = horaCierre;
        this.costoMantenimiento = costoMantenimiento;
    }

    public ZonasComunes(String descripcion, String horaInicio, String horaCierre) {
        this.descripcion = descripcion;
        this.horaInicio = horaInicio;
        this.horaCierre = horaCierre;
    }

    public ZonasComunes() {
    }

    public String getHoraCierre() {
        return horaCierre;
    }

    public void setHoraCierre(String horaCierre) {
        this.horaCierre = horaCierre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public double getCostoMantenimiento() {
        return costoMantenimiento;
    }

    public void setCostoMantenimiento(double costoMantenimiento) {
        this.costoMantenimiento = costoMantenimiento;
    }

    @Override
    public String toString() {
        return "ZonasComunes{" + "descripcion=" + descripcion + ", horaInicio=" + horaInicio + ", horaCierre=" + horaCierre + ", costoMantenimiento=" + costoMantenimiento + '}';
    }
}
